/**
 * Deployment Health Audit Script
 * Tests all FlashFusion deployment URLs and generates health report
 */

import https from 'https';
import http from 'http';
import fs from 'fs/promises';
import path from 'path';

interface Deployment {
  id: string;
  name: string;
  url: string;
  platform: string;
  purpose: string;
  notes: string;
}

interface AuditResult {
  id: string;
  name: string;
  url: string;
  platform: string;
  status: 'alive' | 'slow' | 'degraded' | 'dead' | 'ssl-invalid';
  httpStatus?: number;
  responseTime?: number;
  sslValid: boolean;
  error?: string;
  recommendation: string;
  tested_at: string;
}

interface AuditReport {
  timestamp: string;
  summary: {
    total: number;
    alive: number;
    slow: number;
    degraded: number;
    dead: number;
    sslInvalid: number;
    platforms: Record<string, number>;
  };
  results: AuditResult[];
}

const TIMEOUT_MS = 10000;
const SLOW_THRESHOLD_MS = 3000;
const DEGRADED_THRESHOLD_MS = 10000;

async function testUrl(url: string): Promise<{
  status: number;
  responseTime: number;
  sslValid: boolean;
  error?: string;
}> {
  return new Promise((resolve) => {
    const startTime = Date.now();
    const urlObj = new URL(url);
    const client = urlObj.protocol === 'https:' ? https : http;

    const req = client.get(url, {
      timeout: TIMEOUT_MS,
      headers: {
        'User-Agent': 'FlashFusion-Audit-Bot/1.0'
      }
    }, (res) => {
      const responseTime = Date.now() - startTime;
      
      // Consume response to prevent memory leak
      res.resume();

      resolve({
        status: res.statusCode || 0,
        responseTime,
        sslValid: true
      });
    });

    req.on('error', (error: any) => {
      const responseTime = Date.now() - startTime;
      
      // Check for SSL errors
      const sslValid = !error.message.includes('CERT_') && 
                       !error.message.includes('SSL');

      resolve({
        status: 0,
        responseTime,
        sslValid,
        error: error.message
      });
    });

    req.on('timeout', () => {
      req.destroy();
      resolve({
        status: 0,
        responseTime: TIMEOUT_MS,
        sslValid: true,
        error: 'Request timeout'
      });
    });
  });
}

function determineStatus(
  httpStatus: number,
  responseTime: number,
  sslValid: boolean,
  error?: string
): 'alive' | 'slow' | 'degraded' | 'dead' | 'ssl-invalid' {
  if (!sslValid) return 'ssl-invalid';
  if (httpStatus === 0 || httpStatus >= 400 || error) return 'dead';
  if (responseTime > DEGRADED_THRESHOLD_MS) return 'degraded';
  if (responseTime > SLOW_THRESHOLD_MS) return 'slow';
  return 'alive';
}

function makeRecommendation(deployment: Deployment, result: AuditResult): string {
  // KEEP criteria
  if (deployment.purpose === 'primary') {
    return 'KEEP - Primary production instance';
  }

  if (deployment.purpose === 'feature' && result.status === 'alive') {
    return 'KEEP - Unique feature, still functional';
  }

  if (deployment.notes.includes('KEEP')) {
    return 'KEEP - Marked as essential';
  }

  // MIGRATE criteria
  if (deployment.notes.includes('PERSONAL ACCOUNT')) {
    return '⚠️  MIGRATE - Bus factor risk on personal account';
  }

  // DEPRECATE criteria
  if (result.status === 'dead') {
    return 'DEPRECATE - Deployment is dead';
  }

  if (deployment.notes.includes('duplicate')) {
    return 'DEPRECATE - Duplicate of another instance';
  }

  if (deployment.notes.includes('Unknown purpose')) {
    return 'DEPRECATE - No clear purpose documented';
  }

  if (deployment.purpose === 'testing' && result.status !== 'alive') {
    return 'DEPRECATE - Test instance no longer functional';
  }

  // REVIEW criteria
  if (result.status === 'slow' || result.status === 'degraded') {
    return 'REVIEW - Performance issues detected';
  }

  return 'REVIEW - Manual review recommended';
}

async function runAudit(platformFilter?: string): Promise<AuditReport> {
  console.log('🔍 FlashFusion Deployment Health Audit');
  console.log('━'.repeat(50) + '\n');

  // Load deployments
  const deploymentsPath = path.join(__dirname, '../data/deployments.json');
  const deploymentsData = await fs.readFile(deploymentsPath, 'utf-8');
  const { deployments } = JSON.parse(deploymentsData);

  // Filter by platform if specified
  let deploymentsToTest = deployments as Deployment[];
  if (platformFilter) {
    deploymentsToTest = deploymentsToTest.filter(
      d => d.platform.toLowerCase() === platformFilter.toLowerCase()
    );
    console.log(`📊 Testing ${deploymentsToTest.length} ${platformFilter} deployments...\n`);
  } else {
    console.log(`📊 Testing ${deploymentsToTest.length} deployments across all platforms...\n`);
  }

  // Group by platform for organized output
  const byPlatform = deploymentsToTest.reduce((acc, d) => {
    if (!acc[d.platform]) acc[d.platform] = [];
    acc[d.platform].push(d);
    return acc;
  }, {} as Record<string, Deployment[]>);

  const results: AuditResult[] = [];

  // Test each platform group
  for (const [platform, platformDeployments] of Object.entries(byPlatform)) {
    console.log(`\n${platform.toUpperCase()} (${platformDeployments.length})`);
    console.log('─'.repeat(50));

    for (const deployment of platformDeployments) {
      const testResult = await testUrl(deployment.url);
      const status = determineStatus(
        testResult.status,
        testResult.responseTime,
        testResult.sslValid,
        testResult.error
      );

      const result: AuditResult = {
        id: deployment.id,
        name: deployment.name,
        url: deployment.url,
        platform: deployment.platform,
        status,
        httpStatus: testResult.status,
        responseTime: testResult.responseTime,
        sslValid: testResult.sslValid,
        error: testResult.error,
        recommendation: '',
        tested_at: new Date().toISOString()
      };

      result.recommendation = makeRecommendation(deployment, result);
      results.push(result);

      // Print result
      const icon = status === 'alive' ? '✅' : 
                   status === 'slow' ? '⚠️ ' :
                   status === 'degraded' ? '🐌' :
                   status === 'ssl-invalid' ? '🔒' : '❌';
      
      const timeStr = testResult.responseTime ? `${testResult.responseTime}ms` : 'N/A';
      const statusStr = testResult.status ? `HTTP ${testResult.status}` : testResult.error || 'Unknown';
      
      console.log(`  ${icon} ${deployment.name}`);
      console.log(`     ${deployment.url}`);
      console.log(`     ${statusStr} - ${timeStr}`);
      if (result.recommendation.includes('DEPRECATE') || result.recommendation.includes('MIGRATE')) {
        console.log(`     💡 ${result.recommendation}`);
      }
    }
  }

  // Generate summary
  const summary = {
    total: results.length,
    alive: results.filter(r => r.status === 'alive').length,
    slow: results.filter(r => r.status === 'slow').length,
    degraded: results.filter(r => r.status === 'degraded').length,
    dead: results.filter(r => r.status === 'dead').length,
    sslInvalid: results.filter(r => r.status === 'ssl-invalid').length,
    platforms: Object.fromEntries(
      Object.entries(byPlatform).map(([p, deps]) => [p, deps.length])
    )
  };

  // Print summary
  console.log('\n' + '━'.repeat(50));
  console.log('SUMMARY');
  console.log('━'.repeat(50));
  console.log(`Total:         ${summary.total} deployments`);
  console.log(`Alive:         ${summary.alive} (${Math.round(summary.alive / summary.total * 100)}%)`);
  console.log(`Slow:          ${summary.slow} (${Math.round(summary.slow / summary.total * 100)}%)`);
  console.log(`Degraded:      ${summary.degraded} (${Math.round(summary.degraded / summary.total * 100)}%)`);
  console.log(`Dead:          ${summary.dead} (${Math.round(summary.dead / summary.total * 100)}%)`);
  console.log(`SSL Issues:    ${summary.sslInvalid} (${Math.round(summary.sslInvalid / summary.total * 100)}%)`);

  const toDeprecate = results.filter(r => r.recommendation.includes('DEPRECATE')).length;
  const toMigrate = results.filter(r => r.recommendation.includes('MIGRATE')).length;
  const toKeep = results.filter(r => r.recommendation.includes('KEEP')).length;

  console.log(`\nRecommendation: Deprecate ${toDeprecate}, Migrate ${toMigrate}, Keep ${toKeep}`);
  console.log('━'.repeat(50) + '\n');

  return {
    timestamp: new Date().toISOString(),
    summary,
    results
  };
}

async function saveReport(report: AuditReport) {
  const reportsDir = path.join(__dirname, '../reports');
  await fs.mkdir(reportsDir, { recursive: true });

  const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
  const filename = `audit-${timestamp}.json`;
  const filepath = path.join(reportsDir, filename);

  await fs.writeFile(filepath, JSON.stringify(report, null, 2));
  console.log(`💾 Report saved to: ${filepath}\n`);
}

// Main execution
const platformFilter = process.argv[2];

runAudit(platformFilter)
  .then(report => saveReport(report))
  .then(() => process.exit(0))
  .catch(error => {
    console.error('❌ Audit failed:', error);
    process.exit(1);
  });
