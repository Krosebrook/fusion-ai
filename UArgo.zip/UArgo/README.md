# FlashFusion

[![Node.js Version](https://img.shields.io/badge/node-%3E%3D20.0.0-brightgreen)](https://nodejs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.3-blue)](https://www.typescriptlang.org/)
[![Next.js](https://img.shields.io/badge/Next.js-14-black)](https://nextjs.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

A deployment health audit system and universal app generator platform for managing AI-powered applications across multiple hosting platforms.

---

## Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Prerequisites](#prerequisites)
- [Quick Start](#quick-start)
- [Installation](#installation)
- [Configuration](#configuration)
- [Usage](#usage)
  - [Running Audits](#running-audits)
  - [Generating Reports](#generating-reports)
  - [Platform-Specific Commands](#platform-specific-commands)
- [Project Structure](#project-structure)
- [Architecture](#architecture)
- [API Reference](#api-reference)
- [Testing](#testing)
- [Deployment](#deployment)
- [Contributing](#contributing)
- [Security](#security)
- [License](#license)
- [Acknowledgments](#acknowledgments)

---

## Overview

FlashFusion is a comprehensive ecosystem management platform that provides:

1. **Deployment Health Auditing**: Automated monitoring of 40+ deployment URLs across 7 hosting platforms (Vercel, Base44, Replit, Netlify, Lovable, Bolt, and others)
2. **Universal App Generator**: A SaaS platform for generating AI-powered applications across Web, Mobile, Desktop, and Edge platforms
3. **Deprecation Management**: Intelligent recommendations for consolidating redundant deployments

---

## Features

- **Automated URL Testing**: Validates HTTP status, response time, and SSL certificate validity
- **Platform Categorization**: Groups deployments by hosting platform for organized management
- **Health Status Classification**: Categorizes deployments as alive, slow, degraded, dead, or ssl-invalid
- **Smart Analysis Engine**: Identifies duplicates, stale deployments, and unique features
- **Deprecation Recommendations**: Generates actionable recommendations (KEEP, MIGRATE, DEPRECATE, REVIEW)
- **Multiple Export Formats**: Outputs reports in JSON, CSV, and Markdown
- **Concurrent Processing**: Parallel health checks for improved performance
- **Row-Level Security**: Supabase RLS integration for secure multi-tenant data access

---

## Prerequisites

Before you begin, ensure you have the following installed:

| Requirement | Version | Purpose |
|-------------|---------|---------|
| Node.js | >= 20.0.0 | Runtime environment |
| npm or pnpm | Latest | Package management |
| Git | Latest | Version control |

Optional for full functionality:

| Requirement | Purpose |
|-------------|---------|
| Supabase Account | Database and authentication |
| Vercel Account | Deployment hosting |

---

## Quick Start

```bash
# Clone the repository
git clone https://github.com/your-org/uargo.git
cd uargo

# Install dependencies
npm install

# Copy environment template
cp .env.example .env.local

# Run a full deployment audit
npm run audit

# Generate analysis report
npm run analyze

# Export reports
npm run export
```

---

## Installation

### 1. Clone the Repository

```bash
git clone https://github.com/your-org/uargo.git
cd uargo
```

### 2. Install Dependencies

Using npm:
```bash
npm install
```

Using pnpm (recommended for monorepo):
```bash
pnpm install
```

### 3. Configure Environment

```bash
cp .env.example .env.local
```

Edit `.env.local` with your configuration values. See [Configuration](#configuration) for details.

### 4. Verify Installation

```bash
npm run audit --help
```

---

## Configuration

### Environment Variables

Create a `.env.local` file in the project root with the following variables:

| Variable | Required | Description |
|----------|----------|-------------|
| `NEXT_PUBLIC_SUPABASE_URL` | Yes | Supabase project URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Yes | Supabase anonymous key |
| `SUPABASE_SERVICE_ROLE_KEY` | Yes* | Supabase service role key (server-side only) |
| `NEXT_PUBLIC_APP_URL` | No | Application base URL (default: http://localhost:3000) |
| `SEED_DEMO_PASSWORD` | No | Password for demo user seeding (development only) |

*Required for administrative operations and seeding.

### Deployment Data

The `deployments.json` file contains the catalog of deployment URLs to monitor:

```json
{
  "deployments": [
    {
      "id": "vercel-genesis",
      "name": "FlashFusion Genesis",
      "url": "https://flashfusion-genesis.vercel.app",
      "platform": "vercel",
      "purpose": "primary",
      "notes": "Main production instance"
    }
  ]
}
```

#### Deployment Schema

| Field | Type | Description |
|-------|------|-------------|
| `id` | string | Unique identifier |
| `name` | string | Human-readable name |
| `url` | string | Full deployment URL |
| `platform` | string | Hosting platform (vercel, base44, replit, etc.) |
| `purpose` | string | Deployment purpose (primary, testing, feature, deprecated) |
| `notes` | string | Additional context |

---

## Usage

### Running Audits

#### Full Audit (All Platforms)

```bash
npm run audit
```

Output:
```
FlashFusion Deployment Health Audit
====================================

Testing 42 deployments...

Vercel (7)
  [ALIVE] flashfusion-genesis.vercel.app (245ms)
  [ALIVE] int-smart-triage-ai-2-0.vercel.app (312ms)
  [SLOW]  v0-template-evaluation-academy.vercel.app (4.5s)
  [DEAD]  old-instance.vercel.app (404 Not Found)

Base44 (7)
  [ALIVE] flash-fusion-4e98fe60.base44.app (198ms)
  [ALIVE] archon-orchestrator.base44.app (221ms)

====================================
SUMMARY
====================================
Total:      42 deployments
Alive:      28 (67%)
Dead:       14 (33%)
Slow:        5 (12%)
SSL Issues:  2 (5%)
```

### Generating Reports

#### Analysis Report

```bash
npm run analyze
```

Generates `reports/analysis-TIMESTAMP.json` with deprecation recommendations.

#### Export to Multiple Formats

```bash
# Export to CSV
npm run export:csv

# Export to Markdown
npm run export:md

# Export both formats
npm run export
```

### Platform-Specific Commands

```bash
# Audit only Vercel deployments
npm run audit:vercel

# Audit only Base44 deployments
npm run audit:base44

# Audit only Replit deployments
npm run audit:replit

# Audit only Netlify deployments
npm run audit:netlify
```

---

## Project Structure

```
uargo/
├── README.md                 # This file
├── CONTRIBUTING.md           # Contribution guidelines
├── SECURITY.md               # Security policy
├── CHANGELOG.md              # Version history
├── LICENSE                   # MIT License
├── package.json              # Dependencies and scripts
├── tsconfig.json             # TypeScript configuration
├── turbo.json                # Turborepo configuration
├── next.config.js            # Next.js configuration
├── tailwind.config.ts        # Tailwind CSS configuration
├── middleware.ts             # Next.js middleware (auth, security)
├── .env.example              # Environment template
│
├── Core Application
│   ├── page.tsx              # Landing page
│   ├── layout.tsx            # Root layout
│   ├── route.ts              # API health endpoint
│   ├── globals.css           # Global styles
│   └── supabase.ts           # Database client utilities
│
├── Audit Scripts
│   ├── audit.ts              # Main deployment health audit
│   ├── analyze.ts            # Analysis and recommendations
│   ├── export.ts             # Report generation (CSV/JSON/MD)
│   ├── health-check.ts       # Health status verification
│   ├── verify-rls.ts         # Supabase RLS validation
│   └── seed.ts               # Database seeding
│
├── Data
│   ├── deployments.json      # Deployment URL catalog
│   └── 20251122_flashfusion_core.sql  # Database schema
│
├── docs/                     # Documentation
│   ├── ARCHITECTURE.md       # System architecture
│   ├── API.md                # API reference
│   └── DEPLOYMENT.md         # Deployment guide
│
├── reports/                  # Generated reports (gitignored)
│   ├── audit-TIMESTAMP.json
│   ├── analysis-TIMESTAMP.json
│   └── deployment-audit.csv
│
└── mnt/user-data/outputs/    # Nested project templates
    ├── nextjs-monorepo/      # Full-stack monorepo template
    └── supabase-init/        # Database setup toolkit
```

---

## Architecture

For detailed architecture documentation, see [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

### High-Level Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    FlashFusion Platform                     │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐     │
│  │   Audit     │    │  Analysis   │    │   Export    │     │
│  │   Engine    │───▶│   Engine    │───▶│   Engine    │     │
│  └─────────────┘    └─────────────┘    └─────────────┘     │
│         │                                     │             │
│         ▼                                     ▼             │
│  ┌─────────────┐                      ┌─────────────┐      │
│  │ deployments │                      │   reports/  │      │
│  │    .json    │                      │  (output)   │      │
│  └─────────────┘                      └─────────────┘      │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                    Next.js Application                      │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐     │
│  │ Middleware  │    │    API      │    │    UI       │     │
│  │ (Auth/RLS)  │    │   Routes    │    │  Components │     │
│  └─────────────┘    └─────────────┘    └─────────────┘     │
│         │                  │                  │             │
│         └──────────────────┼──────────────────┘             │
│                            ▼                                │
│                    ┌─────────────┐                          │
│                    │  Supabase   │                          │
│                    │ (PostgreSQL)│                          │
│                    └─────────────┘                          │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Technology Stack

| Layer | Technology | Purpose |
|-------|------------|---------|
| Frontend | Next.js 14, React 18, TypeScript | UI and server components |
| Styling | Tailwind CSS, Radix UI | Design system |
| State | Zustand | Client-side state management |
| Database | Supabase (PostgreSQL) | Data persistence with RLS |
| Auth | Supabase Auth | Authentication and authorization |
| Build | Turborepo | Monorepo management |
| Testing | Vitest, Playwright | Unit and E2E testing |
| Monitoring | Sentry, Vercel Analytics | Error tracking and performance |

---

## API Reference

For complete API documentation, see [docs/API.md](docs/API.md).

### Health Check Endpoint

```http
GET /api/health
```

Response:
```json
{
  "status": "healthy",
  "timestamp": "2025-11-22T14:30:00Z",
  "checks": {
    "database": "connected",
    "auth": "operational"
  }
}
```

---

## Testing

### Running Tests

```bash
# Run all tests
npm test

# Run tests in watch mode
npm run test:watch

# Run tests with coverage
npm run test:coverage

# Run E2E tests
npm run test:e2e
```

### Coverage Requirements

| Metric | Target |
|--------|--------|
| Line Coverage | >= 80% |
| Branch Coverage | >= 80% |
| Function Coverage | >= 80% |

---

## Deployment

For detailed deployment instructions, see [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md).

### Vercel Deployment

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy to preview
vercel

# Deploy to production
vercel --prod
```

### Environment Variables

Ensure all required environment variables are configured in your Vercel project settings.

---

## Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

### Quick Start for Contributors

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'feat: add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## Security

For security concerns, please see [SECURITY.md](SECURITY.md).

To report a vulnerability, please email security@flashfusion.dev or use GitHub's private vulnerability reporting feature.

---

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## Acknowledgments

- [Next.js](https://nextjs.org/) - React framework
- [Supabase](https://supabase.com/) - Backend as a service
- [Vercel](https://vercel.com/) - Deployment platform
- [Turborepo](https://turbo.build/) - Monorepo tooling

---

## Support

- Documentation: [docs/](docs/)
- Issues: [GitHub Issues](https://github.com/your-org/uargo/issues)
- Discussions: [GitHub Discussions](https://github.com/your-org/uargo/discussions)

---

**Maintained by the FlashFusion Team**
