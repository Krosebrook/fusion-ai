import { NextResponse } from 'next/server';
import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';

/**
 * Health Check Endpoint
 * 
 * Verifies:
 * - Next.js server is running
 * - Supabase connection is healthy
 * - Environment variables are configured
 */

export async function GET() {
  const checks = {
    nextjs: 'ok',
    supabase: 'unknown',
    env: 'unknown',
    timestamp: new Date().toISOString(),
  };

  // Check environment variables
  const requiredEnvVars = [
    'NEXT_PUBLIC_SUPABASE_URL',
    'NEXT_PUBLIC_SUPABASE_ANON_KEY',
  ];

  const missingEnvVars = requiredEnvVars.filter(
    (varName) => !process.env[varName]
  );

  if (missingEnvVars.length > 0) {
    checks.env = `missing: ${missingEnvVars.join(', ')}`;
    return NextResponse.json(
      {
        status: 'unhealthy',
        checks,
      },
      { status: 503 }
    );
  }

  checks.env = 'ok';

  // Check Supabase connection
  try {
    const cookieStore = await cookies();
    
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          get(name: string) {
            return cookieStore.get(name)?.value;
          },
        },
      }
    );

    // Simple query to test connection
    const { error } = await supabase.from('user_profiles').select('id').limit(1);

    if (error && error.code !== 'PGRST116') {
      // PGRST116 = no rows found (table exists but empty)
      checks.supabase = `error: ${error.message}`;
      return NextResponse.json(
        {
          status: 'degraded',
          checks,
        },
        { status: 503 }
      );
    }

    checks.supabase = 'ok';
  } catch (error) {
    checks.supabase = `error: ${error instanceof Error ? error.message : 'unknown'}`;
    return NextResponse.json(
      {
        status: 'unhealthy',
        checks,
      },
      { status: 503 }
    );
  }

  // All checks passed
  return NextResponse.json({
    status: 'healthy',
    checks,
  });
}

export const dynamic = 'force-dynamic';
