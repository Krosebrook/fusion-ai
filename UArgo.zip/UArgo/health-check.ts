/**
 * Health Check Script
 * Verifies Supabase connection and basic configuration
 */

import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';

dotenv.config();

interface HealthCheck {
  name: string;
  status: 'pass' | 'fail' | 'warn';
  message: string;
  details?: any;
}

const checks: HealthCheck[] = [];

async function runHealthCheck() {
  console.log('🏥 Running Supabase Health Check...\n');

  // Check 1: Environment variables
  const requiredEnvVars = [
    'NEXT_PUBLIC_SUPABASE_URL',
    'NEXT_PUBLIC_SUPABASE_ANON_KEY',
    'SUPABASE_SERVICE_ROLE_KEY'
  ];

  const missingVars = requiredEnvVars.filter(v => !process.env[v]);
  
  if (missingVars.length === 0) {
    checks.push({
      name: 'Environment Variables',
      status: 'pass',
      message: 'All required environment variables are set'
    });
  } else {
    checks.push({
      name: 'Environment Variables',
      status: 'fail',
      message: `Missing: ${missingVars.join(', ')}`,
      details: { missing: missingVars }
    });
  }

  if (missingVars.length > 0) {
    printResults();
    return;
  }

  // Initialize clients
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;

  const anonClient = createClient(supabaseUrl, anonKey);
  const adminClient = createClient(supabaseUrl, serviceKey);

  // Check 2: Supabase connection
  try {
    const { data, error } = await adminClient.from('user_profiles').select('count').limit(1);
    
    if (error) {
      checks.push({
        name: 'Database Connection',
        status: 'fail',
        message: error.message,
        details: { error: error.code }
      });
    } else {
      checks.push({
        name: 'Database Connection',
        status: 'pass',
        message: 'Successfully connected to Supabase'
      });
    }
  } catch (error) {
    checks.push({
      name: 'Database Connection',
      status: 'fail',
      message: error instanceof Error ? error.message : 'Unknown error'
    });
  }

  // Check 3: Tables exist
  const requiredTables = ['user_profiles', 'app_generations', 'deployments'];
  const tableChecks = await Promise.all(
    requiredTables.map(async (table) => {
      try {
        const { error } = await adminClient.from(table).select('id').limit(1);
        return { table, exists: !error };
      } catch {
        return { table, exists: false };
      }
    })
  );

  const missingTables = tableChecks.filter(t => !t.exists).map(t => t.table);
  
  if (missingTables.length === 0) {
    checks.push({
      name: 'Database Schema',
      status: 'pass',
      message: 'All required tables exist'
    });
  } else {
    checks.push({
      name: 'Database Schema',
      status: 'fail',
      message: `Missing tables: ${missingTables.join(', ')}`,
      details: { missing: missingTables }
    });
  }

  // Check 4: RLS enabled
  try {
    const { data: rlsData } = await adminClient.rpc('pg_catalog.pg_tables');
    
    checks.push({
      name: 'Row Level Security',
      status: 'warn',
      message: 'RLS status needs manual verification',
      details: { note: 'Run npm run verify-rls for detailed RLS testing' }
    });
  } catch {
    checks.push({
      name: 'Row Level Security',
      status: 'warn',
      message: 'Could not verify RLS automatically'
    });
  }

  // Check 5: Auth configuration
  try {
    const { data: { users }, error } = await adminClient.auth.admin.listUsers({
      page: 1,
      perPage: 1
    });
    
    if (error) {
      checks.push({
        name: 'Authentication Service',
        status: 'fail',
        message: error.message
      });
    } else {
      checks.push({
        name: 'Authentication Service',
        status: 'pass',
        message: 'Auth service is operational',
        details: { userCount: users?.length || 0 }
      });
    }
  } catch (error) {
    checks.push({
      name: 'Authentication Service',
      status: 'fail',
      message: error instanceof Error ? error.message : 'Unknown error'
    });
  }

  // Check 6: Database size and usage
  try {
    const { data: stats } = await adminClient
      .from('app_generations')
      .select('status', { count: 'exact' });

    checks.push({
      name: 'Database Usage',
      status: 'pass',
      message: 'Database statistics available',
      details: {
        totalGenerations: stats?.length || 0
      }
    });
  } catch {
    checks.push({
      name: 'Database Usage',
      status: 'warn',
      message: 'Could not fetch usage statistics'
    });
  }

  printResults();
}

function printResults() {
  console.log('═══════════════════════════════════════════════════');
  console.log('              HEALTH CHECK RESULTS                  ');
  console.log('═══════════════════════════════════════════════════\n');

  checks.forEach(({ name, status, message, details }) => {
    const icon = status === 'pass' ? '✅' : status === 'fail' ? '❌' : '⚠️';
    console.log(`${icon} ${name}`);
    console.log(`   ${message}`);
    if (details) {
      console.log(`   Details: ${JSON.stringify(details, null, 2)}`);
    }
    console.log();
  });

  const passed = checks.filter(c => c.status === 'pass').length;
  const failed = checks.filter(c => c.status === 'fail').length;
  const warnings = checks.filter(c => c.status === 'warn').length;

  console.log('═══════════════════════════════════════════════════');
  console.log(`SUMMARY: ${passed} passed, ${failed} failed, ${warnings} warnings`);
  console.log('═══════════════════════════════════════════════════\n');

  if (failed === 0) {
    console.log('🎉 Supabase is healthy and ready to use!');
    process.exit(0);
  } else {
    console.error('⚠️  Some health checks failed. Please review the issues above.');
    process.exit(1);
  }
}

runHealthCheck().catch(error => {
  console.error('Fatal error:', error);
  process.exit(1);
});
