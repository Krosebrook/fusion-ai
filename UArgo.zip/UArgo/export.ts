#!/usr/bin/env node

/**
 * Export Audit Results to CSV and Markdown
 * 
 * Generates human-readable reports from audit and analysis data:
 * - CSV: Machine-readable format for Excel/Google Sheets
 * - Markdown: GitHub-friendly format for documentation
 */

import * as fs from 'fs';
import * as path from 'path';

interface Deployment {
  id: string;
  name: string;
  url: string;
  platform: string;
  purpose?: string;
  notes?: string;
}

interface AuditResult {
  id: string;
  url: string;
  status: 'alive' | 'slow' | 'degraded' | 'dead' | 'ssl-invalid' | 'error';
  responseTime: number;
  httpStatus: number | null;
  sslValid: boolean;
  error?: string;
  timestamp: string;
}

interface AnalysisReport {
  summary: {
    total: number;
    keep: number;
    migrate: number;
    deprecate: number;
    review: number;
  };
  recommendations: Recommendation[];
  platformBreakdown: Record<string, PlatformStats>;
  riskAssessment: RiskItem[];
  migrationPlan: MigrationStep[];
}

interface Recommendation {
  deployment: Deployment;
  auditResult: AuditResult;
  action: 'KEEP' | 'MIGRATE' | 'DEPRECATE' | 'REVIEW';
  reason: string;
  priority: 'P0' | 'P1' | 'P2' | 'P3';
  estimatedEffort: string;
  dependencies: string[];
}

interface PlatformStats {
  total: number;
  alive: number;
  slow: number;
  degraded: number;
  dead: number;
  recommendation: string;
}

interface RiskItem {
  type: string;
  severity: string;
  description: string;
  affectedDeployments: string[];
  mitigation: string;
}

interface MigrationStep {
  phase: number;
  name: string;
  deployments: string[];
  estimatedDuration: string;
  prerequisites: string[];
  rollbackPlan: string;
}

// Load analysis results
const analysisPath = path.join(__dirname, '../reports');
const files = fs.readdirSync(analysisPath).filter(f => f.startsWith('analysis-'));

if (files.length === 0) {
  console.error('❌ No analysis reports found. Run `npm run analyze` first.');
  process.exit(1);
}

// Use latest analysis
const latestAnalysis = files.sort().reverse()[0];
const analysisData: AnalysisReport = JSON.parse(
  fs.readFileSync(path.join(analysisPath, latestAnalysis), 'utf-8')
);

// Export to CSV
function exportCSV() {
  const headers = [
    'Deployment Name',
    'URL',
    'Platform',
    'Status',
    'Response Time (ms)',
    'HTTP Status',
    'SSL Valid',
    'Action',
    'Priority',
    'Reason',
    'Estimated Effort'
  ];

  const rows = analysisData.recommendations.map(rec => [
    `"${rec.deployment.name}"`,
    `"${rec.deployment.url}"`,
    rec.deployment.platform,
    rec.auditResult.status || 'N/A',
    rec.auditResult.responseTime || 'N/A',
    rec.auditResult.httpStatus || 'N/A',
    rec.auditResult.sslValid ? 'Yes' : 'No',
    rec.action,
    rec.priority,
    `"${rec.reason}"`,
    `"${rec.estimatedEffort}"`
  ]);

  const csv = [
    headers.join(','),
    ...rows.map(row => row.join(','))
  ].join('\n');

  const csvPath = path.join(analysisPath, 'deployment-audit.csv');
  fs.writeFileSync(csvPath, csv);
  console.log(`✅ CSV exported: ${csvPath}`);
}

// Export to Markdown
function exportMarkdown() {
  const md: string[] = [];

  // Title and summary
  md.push('# FlashFusion Deployment Audit Report\n');
  md.push(`**Generated:** ${new Date().toISOString().split('T')[0]}\n`);
  md.push(`**Total Deployments:** ${analysisData.summary.total}\n`);

  // Executive Summary
  md.push('## Executive Summary\n');
  md.push('| Metric | Count |');
  md.push('|--------|-------|');
  md.push(`| ✅ Keep | ${analysisData.summary.keep} |`);
  md.push(`| 🔄 Migrate | ${analysisData.summary.migrate} |`);
  md.push(`| ❌ Deprecate | ${analysisData.summary.deprecate} |`);
  md.push(`| 👀 Review | ${analysisData.summary.review} |`);
  md.push('');

  // Risk Assessment
  md.push('## Risk Assessment\n');
  if (analysisData.riskAssessment.length > 0) {
    analysisData.riskAssessment.forEach(risk => {
      const icon = risk.severity === 'critical' ? '🔴' : risk.severity === 'high' ? '🟠' : '🟡';
      md.push(`### ${icon} ${risk.type.toUpperCase()} - ${risk.severity.toUpperCase()}\n`);
      md.push(`**Description:** ${risk.description}\n`);
      md.push(`**Affected Deployments:** ${risk.affectedDeployments.join(', ')}\n`);
      md.push(`**Mitigation:** ${risk.mitigation}\n`);
    });
  } else {
    md.push('✅ No significant risks identified.\n');
  }

  // Platform Breakdown
  md.push('## Platform Health\n');
  md.push('| Platform | Total | Alive | Slow | Degraded | Dead | Recommendation |');
  md.push('|----------|-------|-------|------|----------|------|----------------|');
  Object.entries(analysisData.platformBreakdown).forEach(([platform, stats]) => {
    md.push(`| ${platform} | ${stats.total} | ${stats.alive} | ${stats.slow} | ${stats.degraded} | ${stats.dead} | ${stats.recommendation} |`);
  });
  md.push('');

  // Detailed Recommendations
  md.push('## Detailed Recommendations\n');

  // Group by action
  const grouped = {
    KEEP: analysisData.recommendations.filter(r => r.action === 'KEEP'),
    MIGRATE: analysisData.recommendations.filter(r => r.action === 'MIGRATE'),
    DEPRECATE: analysisData.recommendations.filter(r => r.action === 'DEPRECATE'),
    REVIEW: analysisData.recommendations.filter(r => r.action === 'REVIEW')
  };

  // KEEP
  if (grouped.KEEP.length > 0) {
    md.push('### ✅ Keep (Healthy Deployments)\n');
    md.push('| Name | URL | Platform | Response Time | Status |');
    md.push('|------|-----|----------|---------------|--------|');
    grouped.KEEP.forEach(rec => {
      md.push(`| ${rec.deployment.name} | [${rec.deployment.url}](${rec.deployment.url}) | ${rec.deployment.platform} | ${rec.auditResult.responseTime}ms | ${rec.auditResult.status} |`);
    });
    md.push('');
  }

  // MIGRATE
  if (grouped.MIGRATE.length > 0) {
    md.push('### 🔄 Migrate (Personal Account → Team Account)\n');
    md.push('| Name | URL | Platform | Priority | Effort | Reason |');
    md.push('|------|-----|----------|----------|--------|--------|');
    grouped.MIGRATE.forEach(rec => {
      md.push(`| ${rec.deployment.name} | [${rec.deployment.url}](${rec.deployment.url}) | ${rec.deployment.platform} | ${rec.priority} | ${rec.estimatedEffort} | ${rec.reason} |`);
    });
    md.push('');
  }

  // DEPRECATE
  if (grouped.DEPRECATE.length > 0) {
    md.push('### ❌ Deprecate (Dead or Underperforming)\n');
    md.push('| Name | URL | Platform | Status | Reason |');
    md.push('|------|-----|----------|--------|--------|');
    grouped.DEPRECATE.forEach(rec => {
      md.push(`| ${rec.deployment.name} | [${rec.deployment.url}](${rec.deployment.url}) | ${rec.deployment.platform} | ${rec.auditResult.status} | ${rec.reason} |`);
    });
    md.push('');
  }

  // REVIEW
  if (grouped.REVIEW.length > 0) {
    md.push('### 👀 Review (Requires Human Decision)\n');
    md.push('| Name | URL | Platform | Priority | Reason |');
    md.push('|------|-----|----------|----------|--------|');
    grouped.REVIEW.forEach(rec => {
      md.push(`| ${rec.deployment.name} | [${rec.deployment.url}](${rec.deployment.url}) | ${rec.deployment.platform} | ${rec.priority} | ${rec.reason} |`);
    });
    md.push('');
  }

  // Migration Plan
  md.push('## Migration Plan\n');
  analysisData.migrationPlan.forEach(step => {
    md.push(`### Phase ${step.phase}: ${step.name}\n`);
    md.push(`**Duration:** ${step.estimatedDuration}\n`);
    md.push(`**Deployments (${step.deployments.length}):** ${step.deployments.join(', ')}\n`);
    md.push(`**Prerequisites:**`);
    step.prerequisites.forEach(prereq => md.push(`- ${prereq}`));
    md.push(`\n**Rollback Plan:** ${step.rollbackPlan}\n`);
  });

  // Next Steps
  md.push('## Next Steps\n');
  md.push('1. **Immediate (Week 1):**');
  md.push('   - Deprecate dead instances (Phase 1)');
  md.push('   - Set up team accounts for migration targets\n');
  md.push('2. **Short-term (Weeks 2-3):**');
  md.push('   - Migrate personal account deployments (Phase 2)');
  md.push('   - Fix SSL certificate issues\n');
  md.push('3. **Medium-term (Month 2):**');
  md.push('   - Review edge cases (Phase 3)');
  md.push('   - Consolidate to 7-10 target deployments\n');

  const mdPath = path.join(analysisPath, 'deployment-audit.md');
  fs.writeFileSync(mdPath, md.join('\n'));
  console.log(`✅ Markdown exported: ${mdPath}`);
}

// Main execution
const format = process.argv[2] || 'both';

console.log('📊 Exporting deployment audit reports...\n');

if (format === 'csv' || format === 'both') {
  exportCSV();
}

if (format === 'md' || format === 'markdown' || format === 'both') {
  exportMarkdown();
}

console.log('\n✅ Export complete!');
console.log('\nGenerated files:');
console.log('  - deployment-audit.csv (Excel/Google Sheets)');
console.log('  - deployment-audit.md (GitHub/Documentation)');
console.log('\nUsage:');
console.log('  npm run export:csv      # CSV only');
console.log('  npm run export:md       # Markdown only');
console.log('  npm run export          # Both formats');
